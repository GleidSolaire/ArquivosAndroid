package com.example.tarefas;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;
public class TarefasDAO {

    private DBGateway gateway;

    public TarefasDAO(Context context) {
        this.gateway = DBGateway.getInstance(context);
    }

    public boolean SalvarTarefa(Tarefa t) {
        ContentValues values = new ContentValues();

        values.put(TerefasHelper.TITULO, t.getTitulo());
        values.put(TerefasHelper.PRIORIDADE, t.getPrioridade());
        values.put(TerefasHelper.TEMPOESTIMADO, t.getTempoEstimado());

        long result = gateway.getDb().insert(TerefasHelper.TABELA, null, values);

        if (result > 0) {
            return true;
        }
        return false;
    }

  public  void listarTarefas()
  {
      String sql = "SELECT *FROM "+ TerefasHelper.TABELA;
      Cursor cursor = gateway.getDb().rawQuery(sql,null);

      try{
          cursor.moveToFirst();
           while (cursor != null) {

               int Id = cursor.getInt(cursor.getInt(cursor.getColumnIndex(TerefasHelper.ID)));

               String titulo = cursor.getString(cursor.getColumnIndex(TerefasHelper.TITULO));

               String prioridade = cursor.getString(cursor.getColumnIndex(TerefasHelper.PRIORIDADE));

               String tempo = cursor.getString(cursor.getColumnIndex(TerefasHelper.TEMPOESTIMADO));

               Tarefa tarefa = new Tarefa(titulo, tempo, prioridade, Id);

            ListaTarefas.addTarefa(tarefa);
               cursor.moveToNext();
           }
           cursor.close();
      } catch (Exception e) {
          e.printStackTrace();
      }
  }

  public boolean excluirTarefa (int id) {

        String where = TerefasHelper.ID + " = ?";
        String[] args = {String.valueOf(id)};

        long result = gateway.getDb().delete(TerefasHelper.TABELA, where, args);

        if (result >0 ){
            return true;
        }
        return  false;

  }
}
