package com.example.tarefas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetalhesActivity extends AppCompatActivity {

    TextView txtTitulo;
    TextView txtPrioridade;
    TextView txtTempo;
    Button btnConcluir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtTitulo    = findViewById(R.id.txtTitulo);
        txtPrioridade   = findViewById(R.id.txtPrioridade);
        txtTempo      = findViewById(R.id.txtTempo);

        btnConcluir         = findViewById(R.id.btnConcluir);

        Intent intent = getIntent();
        int index = intent.getIntExtra("index", -1);

        if (index == -1 ){
            Toast.makeText(this, "Erro ao carregar detalhes das tarefas!", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
        } else {
            final Tarefa t = ListaTarefas.getTarefa(index);

            txtTitulo.setText("Titulo: " + t.getTitulo());
            txtPrioridade.setText("Titulo: " + t.getPrioridade());
            txtTempo.setText("Titulo: " + t.getTempoEstimado());

            btnConcluir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    TarefasDAO dao = new TarefasDAO(DetalhesActivity.this);

                    if (dao.excluirTarefa(t.getId())){
                        Toast.makeText(DetalhesActivity.this, "Excluido", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent (DetalhesActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(DetalhesActivity.this, "Erro ao deletar", Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }


    }
}
