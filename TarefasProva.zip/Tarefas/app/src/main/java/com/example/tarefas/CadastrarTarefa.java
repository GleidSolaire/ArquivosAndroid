package com.example.tarefas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastrarTarefa extends AppCompatActivity {
    EditText edtTitulo;
    EditText edtPrioridade;
    EditText edtTempo;

    Button btnSalvar;

    String titulo;
    String prioridade;
    String tempo;
    String msg;

    TarefasDAO dao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_tarefa);

        edtTitulo   = findViewById(R.id.edtTitulo);
        edtPrioridade  = findViewById(R.id.edtPrioridade);
        edtTempo      = findViewById(R.id.edtTempo);

        btnSalvar   = findViewById(R.id.btnSalvar);

        dao = new TarefasDAO(CadastrarTarefa.this);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (! edtTitulo.getText().toString().equals("")&&
                !edtPrioridade.getText().toString().equals("")&&
                !edtTempo.getText().toString().equals("")) {
                    titulo = edtTitulo.getText().toString();
                    prioridade = edtPrioridade.getText().toString();
                    tempo = edtTempo.getText().toString();

                    Tarefa tarefa = new Tarefa(titulo, prioridade, tempo, 0);
                    try {
                        if(dao.SalvarTarefa(tarefa)) {
                            msg = "Tarefa Cadastrada!";
                        }else{
                            msg = "Erro ao cadastrar";
                        }
                    }catch (Exception e){
                        msg = "Erro ao conectar ao banco de dados";
                    }
                    Toast.makeText(CadastrarTarefa.this, msg, Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(CadastrarTarefa.this, MainActivity.class));
                }else {
                    Toast.makeText(CadastrarTarefa.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
            }


        });
    }
}
