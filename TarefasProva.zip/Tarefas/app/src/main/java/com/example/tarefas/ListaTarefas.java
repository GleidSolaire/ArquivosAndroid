package com.example.tarefas;

import java.util.ArrayList;

public class ListaTarefas {

    public static   ArrayList<Tarefa> listaTarefas = new ArrayList<>();

    public static void addTarefa(Tarefa t){
        listaTarefas.add(t);
    }

    public static Tarefa getTarefa(int index)
    {
        return listaTarefas.get(index);
    }

    public static ArrayList<Tarefa> getLista(){
        return listaTarefas;
    }

}
