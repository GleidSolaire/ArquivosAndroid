package com.example.tarefas;

import androidx.annotation.NonNull;

public class Tarefa {

    public String Titulo;
    public String Prioridade;
    public String TempoEstimado;
    public int Id;

    public Tarefa(String titulo, String prioridade, String tempoEstimado, int id) {
        Titulo = titulo;
        Prioridade = prioridade;
        TempoEstimado = tempoEstimado;
        Id = id;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getPrioridade() {
        return Prioridade;
    }

    public void setPrioridade(String prioridade) {
        Prioridade = prioridade;
    }

    public String getTempoEstimado() {
        return TempoEstimado;
    }

    public void setTempoEstimado(String tempoEstimado) {
        TempoEstimado = tempoEstimado;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }
}
