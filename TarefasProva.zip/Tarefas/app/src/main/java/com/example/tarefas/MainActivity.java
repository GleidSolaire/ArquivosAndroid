package com.example.tarefas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    RecyclerView rclTarefas;
    Button btnAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rclTarefas = findViewById(R.id.rclTarefas);
        btnAdd = findViewById(R.id.btnAdd);

        if (ListaTarefas.getLista().size() > 0) {
            ListaTarefas.getLista().clear();
        }

        TarefasDAO dao = new TarefasDAO(MainActivity.this);

        try {
            // carrega lista através dos dados provenientes do BD
            dao.listarTarefas();

        } catch (Exception e) {

            e.printStackTrace();
        }


        TarefasAdapter meu = new TarefasAdapter(ListaTarefas.getLista(), getApplicationContext());

        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);

        rclTarefas.setAdapter(meu);
        rclTarefas.setLayoutManager(meuLayout);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, CadastrarTarefa.class));
            }
        });

    }
}