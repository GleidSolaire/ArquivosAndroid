package com.example.tarefas;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class TarefasHolder extends RecyclerView.ViewHolder {


        TextView txtTitulo;
        TextView txtPrioridade;
        TextView txtTempo;

    public TarefasHolder(@NonNull View itemView){
        super(itemView);
        txtTitulo = itemView.findViewById(R.id.txtTitulo);
        txtPrioridade = itemView.findViewById(R.id.txtTempo);
        txtTempo = itemView.findViewById(R.id.txtPrioridade);
}
}
