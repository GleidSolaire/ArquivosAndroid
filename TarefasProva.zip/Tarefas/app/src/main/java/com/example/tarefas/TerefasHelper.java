package com.example.tarefas;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import androidx.annotation.Nullable;
public class TerefasHelper extends  SQLiteOpenHelper {

    // constantes que definem nome do banco, tabela e campos
    public static final String DB = "tarefas_db"; // nome do seu banco
    public static final String TABELA = "tarefas"; // nome da sua tabela
    // OS CAMPOS ABAIXO DEVEM TER RELAÇÃO COM O TIPO DE DADO QUE
    // IRÁ SALVAR NA SUA TABELA
    public static final String ID = "id_tarefas"; // sua chave primária
    public static final String TITULO = "titulo";
    public static final String PRIORIDADE = "prioridade";
    public static final String TEMPOESTIMADO = "tempoEstimado";

    public static final int    VERSAO = 1;

    public TerefasHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // CRIAR TABELA
        String sql = "CREATE TABLE IF NOT EXISTS " +
                TABELA + " ( " +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                TITULO + " VARCHAR, " +
                PRIORIDADE + " VARCHAR, " +
                TEMPOESTIMADO + " VARCHAR);" ;

        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + TABELA);
        onCreate(db);
    }


}
