package com.example.cadastrofilmes;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;


public class FilmesViewHolder extends RecyclerView.ViewHolder {

TextView txtTitulo;
TextView txtAno;

    public FilmesViewHolder(@NonNull View itemView) {
        super(itemView);

        txtTitulo = itemView.findViewById(R.id.txtTitulo);
        txtAno = itemView.findViewById(R.id.txtAno);


    }
}
