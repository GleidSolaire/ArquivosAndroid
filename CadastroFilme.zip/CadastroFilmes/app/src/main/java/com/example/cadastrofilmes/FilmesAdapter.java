package com.example.cadastrofilmes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FilmesAdapter extends RecyclerView.Adapter {

    private ArrayList<Filme> listaFilmes;

    private Context context;

    public FilmesAdapter( ArrayList<Filme> listaFilmes, Context context) {

        this.listaFilmes = listaFilmes;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.celula_filme, parent, false );

        FilmesViewHolder filmesViewHolder = new FilmesViewHolder(view);


        return  filmesViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        FilmesViewHolder filmesViewHolder = (FilmesViewHolder)holder;

        filmesViewHolder.txtTitulo.setText(listaFilmes.get(position).getTitulo());
        filmesViewHolder.txtAno.setText(listaFilmes.get(position).getAno());
       // filmesViewHolder.txtEmail.setText(listaFilmes.get(position).getEmail());


    }

    @Override
    public int getItemCount() {
        return listaFilmes.size();
    }
}
