package com.example.cadastrofilmes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cadastro extends AppCompatActivity {

    EditText edtTitulo;
    EditText edtAno;
    EditText edtGenero;
    EditText edtDiretor;
    Button btnCadastrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtAno = findViewById(R.id.edtAno);
        edtGenero = findViewById(R.id.edtGenero);
        edtDiretor = findViewById(R.id.edtDiretor);
        btnCadastrar = findViewById(R.id.btnAdd);

        btnCadastrar.setOnClickListener(new View.OnClickListener(){

            public void onClick (View view) {
                try {
                    String titulo = edtTitulo.getText().toString();
                    String ano = edtAno.getText().toString();
                    String genero = edtGenero.getText().toString();
                    String diretor = edtDiretor.getText().toString();

                    Filme novofilme = new Filme(titulo,ano,genero,diretor);
                    ListaFilmes.addFilme(novofilme);

                    Toast.makeText(cadastro.this, "Cadastro efetuado!", Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(cadastro.this, MainActivity.class));

                } catch (Exception e) {
                    Toast.makeText(cadastro.this, "Falha ao cadastrar", Toast.LENGTH_SHORT).show();
                }
            }
        });






    }
}
