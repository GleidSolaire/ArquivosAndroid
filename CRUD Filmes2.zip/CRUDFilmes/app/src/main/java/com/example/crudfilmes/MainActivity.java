package com.example.crudfilmes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.security.spec.ECField;

public class MainActivity extends AppCompatActivity {

   RecyclerView rclFilmes;
   Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rclFilmes   = findViewById(R.id.rclFilmes);
        btnAdd      = findViewById(R.id.btnAdd);

        // cada vez que carregar esta activity, devemos limpar
        // a lista local, e carregar os dados do banco, para
        // evitar registros duplicados na lista:
        if(ListaFilmes.getLista().size() > 0){
            ListaFilmes.getLista().clear();
        }

        // cria novo objeto 'dao'
        FilmeDAO dao = new FilmeDAO(MainActivity.this);

        try{
            // carrega lista através dos dados provenientes do BD
            dao.listarFilmes();

        }catch(Exception e){

            e.printStackTrace();
        }

        FilmesAdapter meuAdapter = new FilmesAdapter(ListaFilmes.getLista(), getApplicationContext());

        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(
                getApplicationContext(), LinearLayoutManager.VERTICAL, false);

        rclFilmes.setAdapter(meuAdapter);
        rclFilmes.setLayoutManager(meuLayout);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CadastroActivity.class ));
            }
        });

    }
}
