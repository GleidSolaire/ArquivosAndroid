package com.example.crudfilmes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FilmesHolder extends RecyclerView.ViewHolder {

   TextView txtTituloAno;

    public FilmesHolder(@NonNull View itemView) {
        super(itemView);

        txtTituloAno = itemView.findViewById(R.id.txtTituloAno);
    }
}
