package com.example.crudfilmes;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FilmesAdapter extends RecyclerView.Adapter {

    private ArrayList<Filme> listaFilmes;
    private Context context;

    public FilmesAdapter(ArrayList<Filme> listaFilmes, Context context) {
        this.listaFilmes = listaFilmes;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

       View view = LayoutInflater.from(context).inflate(R.layout.celula_filme, parent, false);

       FilmesHolder filmesHolder = new FilmesHolder(view);

        return filmesHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {

        FilmesHolder filmesHolder = (FilmesHolder) holder;

        String txtToHolder = listaFilmes.get(position).getTitulo() + " (" + listaFilmes.get(position).getAno() + ")";
        filmesHolder.txtTituloAno.setText(txtToHolder);

        filmesHolder.txtTituloAno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent detalhes = new Intent(context, DetalhesActivity.class);
                detalhes.putExtra("index", position);
                detalhes.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(detalhes);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaFilmes.size();
    }
}
