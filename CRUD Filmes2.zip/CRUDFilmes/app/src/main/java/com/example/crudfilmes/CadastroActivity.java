package com.example.crudfilmes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastroActivity extends AppCompatActivity {

   // componentes de interface:
    EditText edtTitulo;
   EditText edtDiretor;
   EditText edtAno;
   EditText edtGenero;
   Button btnSalvar;

   // atributos para cadastro no banco:
    String titulo;
    String diretor;
    int ano;
    String genero;
    String msg; // posteriormente exibir msgs de sucesso ou erro
    FilmeDAO dao; // objeto para manipular dados na tabela 'filme'

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtTitulo   = findViewById(R.id.edtTitulo);
        edtDiretor  = findViewById(R.id.edtDiretor);
        edtAno      = findViewById(R.id.edtAno);
        edtGenero   = findViewById(R.id.edtGenero);
        btnSalvar   = findViewById(R.id.btnSalvar);

        // criar nova instancia de 'dao'
        dao = new FilmeDAO(CadastroActivity.this);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!edtTitulo.getText().toString().equals("") &&
                   !edtDiretor.getText().toString().equals("") &&
                   !edtAno.getText().toString().equals("") &&
                   !edtGenero.getText().toString().equals(""))
                {

                    titulo   = edtTitulo.getText().toString();
                    diretor  = edtDiretor.getText().toString();
                    ano      = Integer.parseInt(edtAno.getText().toString());
                    genero   = edtGenero.getText().toString();

                    Filme f = new Filme(titulo, diretor, ano, genero, 0);

                    try{
                        if(dao.salvarFilme(f)){

                            msg = "Filme cadastrado com sucesso!";
                        }else{

                            msg = "Erro ao cadastrar filme!";
                        }
                    }catch (Exception e){
                        msg = "Erro ao conectar com o banco de dados";
                    }

                    Toast.makeText(CadastroActivity.this, msg, Toast.LENGTH_SHORT).show();
                    
                    startActivity(new Intent(CadastroActivity.this, MainActivity.class));

                }else{

                    Toast.makeText(CadastroActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();

                }

            }
        });

    }
}
