package com.example.crudfilmes;

import java.util.ArrayList;

public class ListaFilmes {

    private static ArrayList<Filme> listaFilmes = new ArrayList<>();

    public static void addFilme(Filme f){
        listaFilmes.add(f);
    }

    public static Filme getFilme(int index)
    {
        return listaFilmes.get(index);
    }

    public static ArrayList<Filme> getLista(){
        return listaFilmes;
    }


}
