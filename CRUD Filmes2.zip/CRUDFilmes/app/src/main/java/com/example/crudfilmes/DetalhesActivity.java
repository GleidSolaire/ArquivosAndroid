package com.example.crudfilmes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DetalhesActivity extends AppCompatActivity {
    TextView txtVerTitulo;
    TextView txtVerDiretor;
    TextView txtVerAno;
    TextView txtVerGenero;
    Button btnEditar;
    Button btnExlcuir;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes);

        txtVerTitulo = findViewById(R.id.txtVerTitulo);
        txtVerDiretor = findViewById(R.id.txtVerDiretor);
        txtVerAno = findViewById(R.id.txtVerAno);
        txtVerGenero = findViewById(R.id.txtVerGenero);
        btnEditar = findViewById(R.id.btnEditar);
        btnExlcuir = findViewById(R.id.btnExcluir);

        Intent intent = getIntent();
        final int index = intent.getIntExtra("index", -1);
        if (index == -1 ) {
            Toast.makeText(DetalhesActivity.this, "Erro, impossivel salvar", Toast.LENGTH_SHORT).show();
            startActivity(new Intent (DetalhesActivity.this, MainActivity.class));
        }else {
         final    Filme f = ListaFilmes.getFilme(index);
            txtVerTitulo.setText("Titulo: "+f.getTitulo());
            txtVerDiretor.setText("Titulo: "+f.getDiretor());
            txtVerAno.setText("Titulo: "+f.getAno());
            txtVerGenero.setText("Titulo: "+f.getGenero());

            btnExlcuir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FilmeDAO dao = new FilmeDAO(DetalhesActivity.this);

                    if(dao.exluirFilmes(f.getId())){
                        Toast.makeText(DetalhesActivity.this, "Filme Deletado!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(DetalhesActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(DetalhesActivity.this, "Erro ao excluir", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }
}
