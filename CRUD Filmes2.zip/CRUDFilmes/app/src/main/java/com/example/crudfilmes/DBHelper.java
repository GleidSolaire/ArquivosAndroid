package com.example.crudfilmes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    // constantes que definem nome do banco, tabela e campos
    public static final String DB = "filmes_db"; // nome do seu banco
    public static final String TABELA = "filmes"; // nome da sua tabela
    // OS CAMPOS ABAIXO DEVEM TER RELAÇÃO COM O TIPO DE DADO QUE
    // IRÁ SALVAR NA SUA TABELA
    public static final String ID = "id_filme"; // sua chave primária
    public static final String TITULO = "titulo";
    public static final String DIRETOR = "diretor";
    public static final String ANO = "ano";
    public static final String GENERO = "genero";
    public static final int    VERSAO = 1;

    public DBHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase bolinho) {

        // CRIAR TABELA
        String sql = "CREATE TABLE IF NOT EXISTS " +
                TABELA + " ( " +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
                TITULO + " VARCHAR, " +
                DIRETOR + " VARCHAR, " +
                ANO + " INTEGER, " +
                GENERO + " VARCHAR );";

        bolinho.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase bolinho, int oldVersion, int newVersion) {
        bolinho.execSQL("DROP TABLE " + TABELA);
        onCreate(bolinho);
    }
}
