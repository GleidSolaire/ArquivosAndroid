package com.example.crudfilmes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DBGateway {

    // instancia do banco de dados
    private static DBGateway gateway;
    // base de dados conectada
    private SQLiteDatabase db;

    // ao criar uma conexão, precisamos saber em qual
    // contexto ela existirá
    public DBGateway(Context context) {
        // cria um objeto do tipo helper para gerar
        // as tabelas nele especificadas
        DBHelper helper = new DBHelper(context);
        // recebe o bd criado  pelo helper com permissão
        // de gravação
        db = helper.getWritableDatabase();
    }

    // retorna uma conexão ativa com o banco
    public static DBGateway getInstance(Context context){
        // se neste momento não tenho conexão ativa
        if(gateway == null) {
            // gera nova conexão
            gateway = new DBGateway(context);
        }
       // retorna conexão ativa
        return gateway;
    }

    // retorna qual a base de dados está sendo acessada
    public SQLiteDatabase getDatabase(){
        return this.db;
    }
}
