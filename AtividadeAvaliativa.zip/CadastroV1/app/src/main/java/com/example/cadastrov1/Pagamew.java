package com.example.cadastrov1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Pagamew extends AppCompatActivity {

    TextView textNome;
    TextView texHoras;
    TextView textValorHora;
    TextView textSalario;
    TextView textIR;
    TextView textInss;
    TextView textFgts;
    TextView textLiquido;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagamew);


        textNome = findViewById(R.id.textNome);
        textValorHora = findViewById(R.id.textValorHora);
        texHoras = findViewById(R.id.textHoras);
        textSalario = findViewById(R.id.textSalario);
        textIR = findViewById(R.id.textIR);
        textInss = findViewById(R.id.textInss);
        textFgts = findViewById(R.id.textFgts);
        textLiquido = findViewById(R.id.textLiquido);


        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String nome = bundle.getString("nome", "");
        Float horas = bundle.getFloat("horas", 0);
        Float valor = bundle.getFloat("valor", 0);


        textNome.setText("Nome: " + nome);
        texHoras.setText("Horas: " + horas);
        textValorHora.setText("Valor hora: " + valor);



            float bruto = horas * valor;

            textSalario.setText("salario bruto: " + bruto);


            float salario=0;



            if(bruto < 1372.81f) {
                 salario = bruto *0;
                 textIR.setText("Imposto de renda: "+salario);
            }

            if (bruto > 1372.81f && bruto <=  2743.25f ) {

                 salario = bruto*0.15f;
                textIR.setText("Imposto de renda: " + salario);
        } else if (bruto > 2743.25f) {

                 salario = bruto * 0.275f;

                textIR.setText("Imposto de renda: " + salario);
            }

            float inss=0;
           if (bruto <= 868.29) {

                inss = bruto*(0.08f);
               textInss.setText("Inss descontado : "+inss);
           }else if (bruto > 869.29 && bruto <= 1447.14) {
               inss = bruto*0.09f;
               textInss.setText("Inss descontado : "+inss);
           }else if(bruto > 1447.14 && bruto <= 2894.28){
                inss = bruto*0.11f;
               textInss.setText("Inss descontado : "+inss);
           }if(bruto > 2894.28f) {
                inss = bruto - 318.37f;

               textInss.setText("Inss descontado :"+inss );
        }


        float fgts=0;

           fgts = bruto*0.08f;
           textFgts.setText("Fgts aportado:" +fgts);


          float liquido = bruto - salario - inss;

          textLiquido.setText("Salario Liquido: "+liquido);

    }

}
