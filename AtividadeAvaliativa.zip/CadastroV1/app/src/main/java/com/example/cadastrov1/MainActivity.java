package com.example.cadastrov1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import android.view.View;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText editNome;
    EditText editHoras;
    EditText editValor;
    Button   btnCalcular;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        editNome    = findViewById(R.id.editNome);

        editHoras = findViewById(R.id.editHoras);

        editValor = findViewById(R.id.editValor);

        btnCalcular = findViewById(R.id.btnCalcular);




        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(editNome.getText().toString().isEmpty() ||
                        editHoras.getText().toString().isEmpty() ||
                        editValor.getText().toString().isEmpty()
                        )
                {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                }else {

                    String nome = editNome.getText().toString();
                    float horas = Float.parseFloat(editHoras.getText().toString());

                    float valor = Float.parseFloat(editValor.getText().toString());




                    // Bundle para armazenar dados que irÃ£o para outra activity
                    Bundle bundle = new Bundle();
                    bundle.putString("nome", nome);
                    bundle.putFloat("horas", horas);
                    bundle.putFloat("valor", valor);

                    Intent intent = new Intent(MainActivity.this, Pagamew.class);
                    intent.putExtras(bundle);

                    // mÃ©todo para iniciar outra activity
                    startActivity(intent);

                }

            }
        });








    }


}
