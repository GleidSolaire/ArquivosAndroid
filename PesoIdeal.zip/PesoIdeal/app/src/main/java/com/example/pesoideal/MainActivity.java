package com.example.pesoideal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText  txtEntrada;
    Button btnCalcular;
    TextView TxtResposta;
    int k = 4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtEntrada = findViewById(R.id.txtEntrada);
        TxtResposta= findViewById(R.id.TxtResposta);
        btnCalcular=findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtEntrada.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Informe a altura", Toast.LENGTH_SHORT).show();
                } else {
                    int altura = Integer.parseInt(txtEntrada.getText().toString());
                    float peso = (altura - 100) - (altura - 150) / k;
                    TxtResposta.setText(peso + " KG");
                    txtEntrada.setText("");
                }
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radmasc:
                if(checked) {
                    k = 4;
                }
                break;
            case R.id.radfem:
                if(checked) {
                    k = 2;
                }
            break;





        }
    }
}
