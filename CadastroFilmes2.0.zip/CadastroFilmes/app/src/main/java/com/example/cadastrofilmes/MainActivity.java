package com.example.cadastrofilmes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {

    Button btnAdd;
    RecyclerView rclFilmes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAdd = findViewById(R.id.btnAdd);



        rclFilmes = findViewById(R.id.rclFilmes);

        if (ListaFilmes.getLista().size() > 0 ) {
            ListaFilmes.getLista().clear();
        }
        FilmeDAO dao = new FilmeDAO(MainActivity.this);
        try {
            // carrega a lista a partir do dados do db
            dao.listarFilmes();
        }catch (Exception e) {
            e.printStackTrace();
        }

        FilmesAdapter filmesAdapter = new FilmesAdapter(ListaFilmes.getLista(), MainActivity.this);

        rclFilmes.setAdapter(filmesAdapter);

        RecyclerView.LayoutManager meuLayout = new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false);

        rclFilmes.setLayoutManager(meuLayout);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, cadastro.class));
            }
        });
    }




}

