package com.example.cadastrofilmes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DBGateway {

    private static  DBGateway gateway;
    private SQLiteDatabase db;

    // ao criar uma conexao, precisamos saber e, qual contexto ela existira
    public DBGateway(Context context) {
        // cria um objeto do tipo helper para gerar as tableas nele especificamente
        DBHelper helper = new DBHelper(context);
        // recebe o bd criado pelo helper com permissao de gravacao
        db = helper.getWritableDatabase();
    }
    // retorna a conexao ativa com o banco
    public  static  DBGateway getInstance(Context context) {
        // se neste momento nao tenho conexao ativa
        if (gateway == null) {
            // gera nova conexao
            gateway = new DBGateway(context);
        }
        // retorna conexao ativa
        return  gateway;

    }
// retorna qual a base de dados esta sendo acessado
    public SQLiteDatabase getDb() {
        return db;
    }
}

