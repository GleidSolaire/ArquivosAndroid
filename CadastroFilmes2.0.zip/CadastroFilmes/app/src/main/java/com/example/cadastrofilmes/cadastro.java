package com.example.cadastrofilmes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.RestrictionEntry;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cadastro extends AppCompatActivity {
    // componentes de UI
    EditText edtTitulo;
    EditText edtAno;
    EditText edtGenero;
    EditText edtDiretor;
    Button btnCadastrar;

    // atributos para cadastro no banco
    String titulo;
    String ano;
    String genero;
    String diretor;
    String msg; // posteriormente exibir msgs de erro
    FilmeDAO dao; // objeto para manipular dados na tebela 'filme'

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtAno = findViewById(R.id.edtAno);
        edtGenero = findViewById(R.id.edtGenero);
        edtDiretor = findViewById(R.id.edtDiretor);
        btnCadastrar = findViewById(R.id.btnAdd);

        // cirar uma instancia do DAO
        dao = new FilmeDAO(cadastro.this);
        btnCadastrar.setOnClickListener(new View.OnClickListener(){

            public void onClick (View view) {
                if (!edtTitulo.getText().toString().equals("") &&
                !edtDiretor.getText().toString().equals("")&&
                !edtAno.getText().toString().equals("")&&
                !edtGenero.getText().toString().equals("")){
                    titulo = edtTitulo.getText().toString();
                    ano = edtAno.getText().toString();
                    diretor = edtDiretor.getText().toString();
                    genero = edtGenero.getText().toString();

                    Filme filme = new Filme(titulo,ano,genero,diretor);
                    try  {
                        if (dao.Salvar(filme)) {
                            msg = "Filme cadastro com sucesso!";
                        } else {
                            msg = "Erro ao salvar";
                        }
                    }catch (Exception e) {
                        msg = "Erro ao conectar ao banco de dados";
                    }
                    Toast.makeText(cadastro.this, msg, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(cadastro.this, MainActivity.class));
                }else{
                    Toast.makeText(cadastro.this, "preencha os campos", Toast.LENGTH_SHORT).show();
                }




            }
        });






    }
}
