package com.example.cadastrofilmes;

public class Filme {

    public String Titulo;
    public String Ano;
    public String genero;
    public String Diretor;


    public Filme(String nome, String ano, String genero, String diretor) {
        Titulo = nome;
        Ano = ano;
        this.genero = genero;
        Diretor = diretor;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getAno() {
        return Ano;
    }

    public void setAno(String ano) {
        Ano = ano;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getDiretor() {
        return Diretor;
    }

    public void setDiretor(String diretor) {
        Diretor = diretor;
    }
}
