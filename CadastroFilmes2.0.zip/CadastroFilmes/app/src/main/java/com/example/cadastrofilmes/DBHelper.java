package com.example.cadastrofilmes;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    //constantes que definem o nome do banco, tabela e campos

    public static final String DB = "filmes_db";

    public static final String TABELA = "filmes";

    public static final String ID = "id_filme";

    public static final String TITULO = "titulo";

    public static final String ANO = "ano";

    public static final String GENERO = "genero";

    public static final String DIRETOR = "diretor";

    public static final int VERSAO = 1;

    public DBHelper(@Nullable Context context) {
        super(context, DB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // criar a tabela
        String sql = "CREATE TABLE  IF NOT EXISTS " +
                TABELA + "(" + ID +"INTEGER PRIMARY KEY AUTOINCREMENT, "+
                TITULO + "VARCHAR, " +
                DIRETOR + "VARCHAR, " +
                ANO + "VARCHAR, " +
                GENERO + "VARCHAR);";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE " + TABELA);
        onCreate(db);

    }
}