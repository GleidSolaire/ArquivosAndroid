package com.example.cadastrofilmes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

public class FilmeDAO {

    private  DBGateway gateway;

    public FilmeDAO (Context context) {
        gateway = DBGateway.getInstance(context);
    }

    public boolean Salvar (Filme filme) {

        ContentValues values = new ContentValues();

        values.put(DBHelper.TITULO, filme.getTitulo());
        values.put(DBHelper.DIRETOR, filme.getDiretor());
        values.put(DBHelper.ANO, filme.getAno());
        values.put(DBHelper.GENERO, filme.getGenero());

        long result = gateway.getDb().insert(DBHelper.TABELA, null, values);

        // result precisa ser long, pois o retorno de um comando sqlite sempre é long

        // acessamos nossa conexao com o banco (gateway);
        // recebemos a informaca de qual banco estamos conectados
        // (getDataBase());
        // informamos que iremos fazer um insert into em alguma tabela do banco
        // o primeiro argumento é o nome da tabela, segundo arg por padrao é null,
        // terceiro ar sao os valores que iremos inserir (values)

        if(result > 0 ) {
            return   true; // cadastrou com sucesso
        }
        return   false; // nao foi possivel cadastrar
    }

    public  void listarFilmes () {
        // criar cursor (uma especia de ponteiro que ira percorrer
        // todos os dados de uma tabela existente no banco de dados

        String sql = "SELECT * FROM " + DBHelper.TABELA;
        Cursor cursor = gateway.getDb().rawQuery(sql, null);

        try {
            // mover cursos para o inicio da tabela proveniente do select
            cursor.moveToFirst();

            // enquanto houver linhas para percorrer
            while (cursor != null) {
                String titulo = cursor.getString(cursor.getColumnIndex(DBHelper.TITULO));
                String diretor = cursor.getString(cursor.getColumnIndex(DBHelper.DIRETOR));
                String ano = cursor.getString(cursor.getColumnIndex(DBHelper.ANO));
                String genero = cursor.getString(cursor.getColumnIndex(DBHelper.GENERO));

                // armazenar variaveis locais no objeto 'f'

                Filme filme  = new Filme(titulo, diretor, ano, genero);
                // armazena na lista local
                ListaFilmes.addFilme(filme);

                // mover para proxima linha[
                cursor.moveToNext();

            } // fim while
            // fechar cursor apos ter percorrido todos os valores
            cursor.close();
        }catch (Exception e) {
         e.printStackTrace();
        }
    }
}
