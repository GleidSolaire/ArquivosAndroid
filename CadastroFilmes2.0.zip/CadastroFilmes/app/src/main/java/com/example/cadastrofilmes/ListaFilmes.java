package com.example.cadastrofilmes;

import java.util.ArrayList;

public class ListaFilmes {

    private static ArrayList<Filme> listadefilmes = new ArrayList<>();



    public static void addFilme (Filme f) {
        listadefilmes.add(f);
    }

    public static  ArrayList<Filme> getLista ()
    {
        return listadefilmes;
    }

    public static  Filme getFilme (int index) {

        return listadefilmes.get(index);
    }



    public static  void gerarLista () {

        listadefilmes.add(new Filme ( "Se eu fosse vc", "2000" , "comedia", "eu"));
        listadefilmes.add(new Filme( "Furia de ninjas",  "1999", "comedia", "eu e vc"));
        listadefilmes.add(new Filme("Os Macacos que se mordam",  "1977", "terror", "lucefer"));
        listadefilmes.add(new Filme("Asas de Anjo",  "2019", "documentario", "fidel castro"));
        listadefilmes.add(new Filme( "As formigas atomicas",  "2019", "animação", "marie curie"));
    }
}



