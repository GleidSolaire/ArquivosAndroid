package com.example.listadecontados;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ContatoAdapter extends RecyclerView.Adapter {

    // dois dados fundamentais
    //fonte de dados
    private ArrayList<Contato> listadeContatos;
    //contexto
    private Context context;

    public ContatoAdapter(ArrayList<Contato> listadeContatos, Context context) {
        this.listadeContatos = listadeContatos;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //determina a layout de cada celula do holder na view
       //innformamos o contexto em que sera inserida esta recyler list e qual o arquivo xml responsavel
        // pelo layout de cada celula
        // no nosso exemplo, é o celula.xml

        View view = LayoutInflater.from(context).inflate(R.layout.celula_contato, parent, false );

        ContatoViewHolder contatoViewHolder = new ContatoViewHolder(view);


        return contatoViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ContatoViewHolder contatoViewHolder = (ContatoViewHolder)holder;
        contatoViewHolder.txtNome.setText(listadeContatos.get(position).getNome());
        contatoViewHolder.txtFone.setText(listadeContatos.get(position).getFone());
        contatoViewHolder.txtEmail.setText(listadeContatos.get(position).getEmail());




    }

    @Override
    public int getItemCount() {
        return listadeContatos.size();
    }
}
