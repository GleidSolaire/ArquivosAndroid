package com.example.listadecontados;
import java.util.ArrayList;

public class ListaContatos {

    private static ArrayList<Contato> listadecontatos = new ArrayList<>();

    public static void addContato (Contato c) {
        listadecontatos.add(c);
    }

    public static  ArrayList<Contato> getLista ()
    {
      return listadecontatos;
    }

    public static  Contato getContato (int index) {

        return listadecontatos.get(index);
    }


    public static  void gerarLista () {

        listadecontatos.add(new Contato( "Jao Silva",  "999998777", "jao.silva@email.com"));
        listadecontatos.add(new Contato( "Megan Tija",  "999998777", "meg.tija@email.com"));
        listadecontatos.add(new Contato("Saulo de Paula",  "999998777", "saulop@email.com"));
        listadecontatos.add(new Contato("Tiago Junqueira",  "999998777", "junqueira.tiago@email.com"));
        listadecontatos.add(new Contato( "Jair Caperoto",  "171717171717", "jair.17@email.com"));
    }
 }


