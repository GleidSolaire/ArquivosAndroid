package com.example.alcoolougasolina;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {



    EditText edtValor;
    Button btnVerificar;

    TextView txtResposta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtValor = findViewById(R.id.edtValor);
        btnVerificar = findViewById(R.id.btnVerificar);
        txtResposta = findViewById(R.id.txtResposta);

        btnVerificar.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
              if(edtValor.getText().toString().isEmpty()) {

                  Toast.makeText(MainActivity.this, "Digite o valor da gasolina", Toast.LENGTH_SHORT).show();
              } else {
                  float valor = Float.parseFloat(edtValor.getText().toString());
                  float resposta = valor *0.7f;
String ValorFinal = String.format(Locale.FRANCE, "%.2f", resposta);
                  txtResposta.setText("R$ "+ValorFinal);
                  edtValor.setText("");
              }


            }
        });


    }
}
